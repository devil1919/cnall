//Assignment 05
#include<iostream>
#include<cstdlib>
#include<string>
using namespace std;
static string host;
static string rhost;
void pingp(string);
int main()
{
int i=0;
cout<<"Enter ur choice: \n 1. Ping to Same Subnet Machine\n 2. Ping to Different Subnet Machine\n";
cin>>i;
cout<<"Enter host IP address & Mask";
cin>>host;
switch(i)
{case 1:
pingp(host);
break;
case 2:
cout<<"Enter IP addres & Mask of another Subnet n/w";
cin>>rhost;
system(("ifconfig eth0:1 "+rhost).c_str());
pingp(rhost);
break;
default: cout<<"Enter proper choice";
}
return 0;}
void pingp(string host)
{
system(("ping "+host).c_str());
}


/*
How to run program:
Akshay@ak:~$ g++ -o p pingc.cc
Akshay@ak:~$ ./p

Output:
Enter ur choice:
 1. Ping to Same Subnet Machine
 2. Ping to Different Subnet Machine
1
Enter host IP address & Mask127.0.0.1 255.0.0.0
PING 127.0.0.1 (127.0.0.1) 56(84) bytes of data.
64 bytes from 127.0.0.1: icmp_seq=1 ttl=64 time=0.021 ms
64 bytes from 127.0.0.1: icmp_seq=2 ttl=64 time=0.050 ms
64 bytes from 127.0.0.1: icmp_seq=3 ttl=64 time=0.052 ms
64 bytes from 127.0.0.1: icmp_seq=4 ttl=64 time=0.043 ms
64 bytes from 127.0.0.1: icmp_seq=5 ttl=64 time=0.036 ms

2
Enter host IP address & Mask 10.2.0.10 255.255.0.0
PING 10.2.0.10 (10.2.0.10 ) 56(84) bytes of data.
64 bytes from 10.2.0.10 : icmp_seq=1 ttl=255 time=0.336 ms
64 bytes from 10.2.0.10 : icmp_seq=1 ttl=255 time=0.334 ms */
