#include<iostream>
#include<cstdlib>
#include<string>
using namespace std;
static string host;
static string rhost;
void pingp(string);
int main()
{
	int i=0;
	cout<<"Enter your choice:\n";
	cout<<"1.Ping to same subnet machine.\n";
	cout<<"2.Ping to different subnet machine.\n";
	cin>>i;
	cout<<"Enter host ip address mask:";
	cin>>host;
	switch(i)
	{
		case1:pingp(host);
		break;

		case2:cout<<"Enter ip and mask address of another machine:";
		cin>>rhost;
		system(("ifconfig eth0:1"+rhost).c_str());
		pingp(rhost);
		break;

		default:cout<<"Enter valid choice";
	}
	return 0;
}
