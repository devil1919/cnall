import socket

port = 23001
ip = '127.0.0.1'


sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

sock.connect((ip,port))

sock.send("hello from client")


print sock.recv(100)
sock.close()






