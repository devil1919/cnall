import socket
port = 23000
ip = ''

clisock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

clisock.sendto("hello from client", (ip, port))
print clisock.recv(100)
clisock.close()
