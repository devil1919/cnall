import java.io.*; 
import java.net.*;
import java.net.Socket; 
class client
{ 

    public static void main(String argv[]) throws Exception 
    { 
        String sentence,s1; 
        String modifiedSentence; 

        BufferedReader inFromUser = 
          new BufferedReader(new InputStreamReader(System.in)); 

        Socket clientSocket = new Socket("127.0.0.1", 6666); 

        DataOutputStream outToServer = 
          new DataOutputStream(clientSocket.getOutputStream()); 
BufferedReader inFromServer = 
          new BufferedReader(new
          InputStreamReader(clientSocket.getInputStream())); 
System.out.println("Enter your Message:"); 
        sentence = inFromUser.readLine(); 

        outToServer.writeBytes(sentence + '\n'); 

 	s1 = inFromServer.readLine();
	System.out.println("FROM SERVER: " + s1); 
        clientSocket.close(); 
}
}

